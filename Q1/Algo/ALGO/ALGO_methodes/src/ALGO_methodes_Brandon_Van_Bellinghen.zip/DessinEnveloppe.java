/**
 *
 * @author Van Bellinghen Brandon
 *
 */
public class DessinEnveloppe {

    public static Tortue tortue = new Tortue();

    public static void main(String[] args) {
        tortue.accelerer();
        tortue.dessinerUnCarre(100);
        tortue.dessinerUnTriangle(100);
    }
}
