/**
 *
 * @author Van Bellinghen Brandon
 *
 */
public class DessinLunettes {

    public static Tortue tortue = new Tortue();

    public static void main(String[] args) {
        tortue.accelerer();
        tortue.dessinerUnCarre(100);
        tortue.avancer(150);
        tortue.dessinerUnCarre(100);
    }
}
