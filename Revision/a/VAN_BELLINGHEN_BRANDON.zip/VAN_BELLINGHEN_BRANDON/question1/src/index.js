import 'bootstrap/dist/css/bootstrap.min.css';
import './stylesheets/main.css';
import GamePage from './Components/Pages/GamePage';

GamePage();