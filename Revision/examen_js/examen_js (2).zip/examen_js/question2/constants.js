const users = ["user1", "user2", "user3"];
const products = [
    {
        "id": 1,
        "name": "product1",
        "price": 10,
    },
    {
        "id": 2,
        "name": "product2",
        "price": 20,
    },
    {
        "id": 3,
        "name": "product3",
        "price": 30,
    },
    {
        "id": 4,
        "name": "product4",
        "price": 40,
    },
    {
        "id": 5,
        "name": "product5",
        "price": 50,
    },
];

module.exports = { users, products };