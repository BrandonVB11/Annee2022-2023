import HomePage from '../Pages/HomePage';
import NewPage from '../Pages/NewPage';

const routes = {
  '/': HomePage,
  '/new': NewPage,
};

export default routes;
